def main():
    print('Hello world')

main()
    
    
