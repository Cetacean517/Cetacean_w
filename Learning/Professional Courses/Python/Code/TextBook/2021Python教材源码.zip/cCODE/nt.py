if __name__=='__main__':
    print('Please use me as a module.')
